=== DigiWp Ai Bridge ===
Connects this WordPress site to the DigiWP panel (ai.digiwp.com) through the
DigiWP server (api.digiwp.com). Install, activate, then Tools → DigiWp Ai Bridge →
Hub Connector Mode: turn it on and paste the shared secret from your panel.
The server URL is pre-filled. From then on the site only accepts signed commands
from your DigiWP server.
