=== DigiWp Ai Bridge ===
Connects this WordPress site to the DigiWP panel (ai.digiwp.com) through the
DigiWP server (api.digiwp.com). Install, activate, then Tools → DigiWp Ai Bridge →
Hub Connector Mode: turn it on and paste the shared secret from your panel.
The server URL is pre-filled. From then on the site only accepts signed commands
from your DigiWP server.

Development playbooks are intentionally not stored in the site's webroot. The
same 18 playbooks remain available through list_wp_skills/get_wp_skill and are
loaded as read-only text from the configured DigiWP server only when requested.
The built-in cookbook and all site-management tools remain available offline.
